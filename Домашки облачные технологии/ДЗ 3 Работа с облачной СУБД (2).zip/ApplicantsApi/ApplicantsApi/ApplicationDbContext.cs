﻿using Microsoft.EntityFrameworkCore;

namespace ApplicantsApi
{
    public class ApplicationDbContext : DbContext 
    {
        public required DbSet<Applicant> Applicants { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = @"
                Host=aws-0-eu-central-1.pooler.supabase.com;
                Port=5432;
                Database=postgres;
                Username=postgres.mfgcciptstkxftjkaelw;
                Password=postgres;
            ";
            optionsBuilder.UseNpgsql(connectionString);
        }
    }
}
